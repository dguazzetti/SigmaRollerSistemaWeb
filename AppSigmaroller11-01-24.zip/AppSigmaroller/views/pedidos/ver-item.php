<?php

if(!isset($_SESSION)){
  session_start();
}
//Obtengo los datos de la sesion
$nombre = $_SESSION['usuario'];
$nombre = ucfirst($nombre);
$tipoUsuario = $_SESSION['tipoUsuario'];
$tipoUsuario = ucfirst($tipoUsuario);

require "../template/head.php";
?>

<body>
  <?php
  require "../template/header.php";

  ?>
  <!-- Main -->
  <main id="main" class="main">

    <div class="pagetitle">
      <h1> Ver Item</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?= $baseUrl; ?>/views/pedidos/ver-pedidos.php">Ver Item</a></li>
          <li class="breadcrumb-item active">Item</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <!-- Seccion Ver Items-->
    <section class="section dashboard">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Ver Item</h5>
              <table class="table">
                <!-- ver  Item Producto-->
                <tbody id="tblBodyVerItemProducto">
                  <tr>
                    <th scope="row" style="text-align: right">Producto:</th>
                    <td id="txtVerNombreProd"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Precio:</th>
                    <td id="numVerPrecioProd"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Codigo Articulo:</th>
                    <td id="numVerCodArtProd"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Observaciones:</th>
                    <td id="txtVerObsProd"></td>
                  </tr>
                </tbody>
                <!-- ver  Item Cortina Roller-->
                <tbody id="tblBodyVerItemCR">
                  <tr>
                    <th scope="row" style="text-align: right">Cortina Roller:</th>
                    <td id="numVerCR"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Tela:</th>
                    <td id="txtVerTelaCR"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Color:</th>
                    <td id="txtVerColorCR"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Comando:</th>
                    <td id="txtVerComandoCR"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Cadena:</th>
                    <td id="txtVerCadenaCR"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Caída:</th>
                    <td id="txtVerCaidaCR"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Ancho:</th>
                    <td id="numVerAnchoCR"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Alto:</th>
                    <td id="numVerAltoCR"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Valor:</th>
                    <td id="numVerValorCR"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Termofusión:</th>
                    <td id="txtVerTermofusionCR"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Mecanismo Color:</th>
                    <td id="txtVerMecColCR"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Contrapeso Cadena:</th>
                    <td id="txtVerContrapesoCR"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Observaciones:</th>
                    <td id="txtVerObsCR"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Mecanismo:</th>
                    <td id="txtVerMecanismoCR"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Soporte:</th>
                    <td id="txtVerSoporteCR"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Motor:</th>
                    <td id="txtVerMotorCR"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Duplica:</th>
                    <td id="txtVerDuplicaCR"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Cantidad:</th>
                    <td id="numVerCantidadCR"></td>
                  </tr>
                </tbody>

                <!-- ver  Item Cortina confeccion-->
                <tbody id="tblBodyVerItemCC">
                  <tr>
                    <th scope="row" style="text-align: right">Cortina Confección:</th>
                    <td id="numVerCC"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Tela:</th>
                    <td id="txtVerTelaCC"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Color:</th>
                    <td id="txtVerColorCC"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Ancho:</th>
                    <td id="numVerAnchoCC"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Alto:</th>
                    <td id="numVerAltoCC"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Cantidad de Paños:</th>
                    <td id="numCantPanCC"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Valor:</th>
                    <td id="numVerValorCC"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Observaciones:</th>
                    <td id="txtVerObsCC"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Mecanismo:</th>
                    <td id="txtVerMecCC"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Motor:</th>
                    <td id="txtVerMotorCC"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Duplica:</th>
                    <td id="txtVerDuplicaCC"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Cantidad:</th>
                    <td id="numVerCantidadCC"></td>
                  </tr>
                </tbody>

                <!-- ver  Item Cortina confeccion-->
                <tbody id="tblBodyVerItemBV">
                  <tr>
                    <th scope="row" style="text-align: right">Cortina Banda Vertical:</th>
                    <td id="numVerBV"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Tela:</th>
                    <td id="txtVerTelaBV"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Color:</th>
                    <td id="txtVerColorBV"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Comando:</th>
                    <td id="txtVerComandoBV"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Ancho:</th>
                    <td id="numVerAnchoBV"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Alto:</th>
                    <td id="numVerAltoBV"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Valor:</th>
                    <td id="numVerValorBV"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Observaciones:</th>
                    <td id="txtVerObsBV"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Mecanismo:</th>
                    <td id="txtVerMecBV"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Cantidad Mensulas:</th>
                    <td id="numverMensBV"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Motor:</th>
                    <td id="txtVerMotorBV"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Motor:</th>
                    <td id="txtVerAperturaBV"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Duplica:</th>
                    <td id="txtVerDuplicaBV"></td>
                  </tr>
                  <tr>
                    <th scope="row" style="text-align: right">Cantidad:</th>
                    <td id="numVerCantidadBV"></td>
                  </tr>
                </tbody>
              </table>
              <div class="text-center">
                <button type="reset" class="btn btn-danger style" onclick="fntCancelarNuevoLeg()">ATRAS</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

  </main><!-- Fin main -->

  <?php
  require "../template/footer.php";
  ?>