// FUNCIONES NUEVO CREDITO//

if (document.querySelector("#frmNuevoCredito")) {
    let frmNewCredito = document.querySelector("#frmNuevoCredito");
    frmNewCredito.onsubmit = function (e) {
        e.preventDefault(); // para que no se recargue la pagina
        fntGuardarCredito();
    }

    async function fntGuardarCredito() {

        try {
            const data = new FormData(frmNewCredito);
            let resp = await fetch(base_url + "controllers/comprobante.php?op=guardarCredito", {
                method: 'POST',
                mode: 'cors',
                cache: 'no-cache',
                body: data
            });
            json = await resp.json();
            if (json.status) {
                swal("Crédito", json.msg, "success")
                .then(() => {
                    frmNewCredito.reset();
                    location.reload();
                });
            } else {
                swal("Crédito", json.msg, "error");
            }
        } catch (err) {
            console.log("Ocurrio un error: " + er);
        }
    }
}

// FUNCIONES NUEVO DEBITO//

if (document.querySelector("#frmNuevoDebito")) {
    let frmNewDebito = document.querySelector("#frmNuevoDebito");
    frmNewDebito.onsubmit = function (e) {
        e.preventDefault(); // para que no se recargue la pagina
        fntGuardarDebito();
    }

    async function fntGuardarDebito() {

        try {
            const data = new FormData(frmNewDebito);
            let resp = await fetch(base_url + "controllers/comprobante.php?op=guardarDebito", {
                method: 'POST',
                mode: 'cors',
                cache: 'no-cache',
                body: data
            });
            json = await resp.json();
            if (json.status) {
                swal("Débito", json.msg, "success")
                .then(() => {
                    frmNewDebito.reset();
                    location.reload();
                });
            } else {
                swal("Débito", json.msg, "error");
            }
        } catch (err) {
            console.log("Ocurrio un error: " + er);
        }
    }
}

// FUNCIONES PARA LISTAR COMPROBANTES Y CTA CORRIENTE// 

async function getComprobantes(id) {
    document.querySelector("#tblBodyComprobantes").innerHTML = "";
    
    try {
        const data = new FormData();
        data.append('id', id);
        let resp = await fetch(base_url + "controllers/comprobante.php?op=listaComprobantes", {
            method: 'POST',
            mode: 'cors',
            cache: 'no-cache',
            body: data
        });
        json = await resp.json();
        var fecha;
        if (json.status) {
            let data = json.data;
            data.forEach(item => {
                fecha = convertirFecha(item.fecha);
                let newtr = document.createElement("tr");
                newtr.id = "row_ " + item.id;
                newtr.innerHTML = `<tr>
                                    <th scope="row" style="display: none;">${item.id}</th>
                                    <td style="text-align: center;">${fecha}</td>
                                    <td style="text-align: center;">${item.descripcion}</td>
                                    <td style="text-align: center;">$ ${item.valor}</td>
                                    <td style="text-align: center;">${item.tipoComprobante}</td>`;
                document.querySelector("#tblBodyComprobantes").appendChild(newtr);
            });

        }
    } catch (err) {
        console.log("Ocurrio un error" + err);
    }

}

async function getCuentaCorriente(id) {
   
    try {
        const data = new FormData();
        data.append('id', id);
        let resp = await fetch(base_url + "controllers/comprobante.php?op=listaCuentaCorriente", {
            method: 'POST',
            mode: 'cors',
            cache: 'no-cache',
            body: data
        });
        json = await resp.json();
        if (json.status) {
            document.querySelector("#tblBodyCtaCorriente").innerHTML = "";
            let data = json.data;
           
            let newtr = document.createElement("tr");
            newtr.id = "row_ " + data.id;
            fecha =convertirFecha(data.fecha);
            newtr.innerHTML = `<tr>
                                <th scope="row" style="display: none;">${data.id}</th>
                                <td style="text-align: center;">$ ${data.saldo}</td>
                                <td style="text-align: center;">${data.tipoComprobante} - ${data.descripcion}</td>
                                <td style="text-align: center;">${fecha}</td>`;
            document.querySelector("#tblBodyCtaCorriente").appendChild(newtr);

        }
    } catch (err) {
        console.log("Ocurrio un error" + err);
    }
}

function convertirFecha(fecha){
    // Dividir la cadena de fecha y hora
    var partes = fecha.split(" ");
    var fechaParte = partes[0];
    var horaParte = partes[1];

    var fechaFormateada = fechaParte.split("-").reverse().join("-");
    fecha = fechaFormateada + ' ' + horaParte;
    return fecha;
}

