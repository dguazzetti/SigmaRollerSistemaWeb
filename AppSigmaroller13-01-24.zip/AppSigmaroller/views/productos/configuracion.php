<?php

require "../template/head.php";


?>

<body>

    <?php
    require "../template/header.php";
    ?>


    <!-- Main -->
    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Productos</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo $baseUrl; ?>/views/legajos/ver-todos.php">Productos</a></li>
                    <li class="breadcrumb-item active">Configuración</li>
                </ol>
            </nav>
        </div><!-- Fin Titulo -->

        <section class="section">
            <div class="row">
                <!-- Comienzo tabla  agrupamiento-->
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Cortinas</h5>
                            <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalAgrupamientos">
                                Nuevo Producto
                            </button>
                            <br>
                            <br>
                            <table id="tblAgrupamientos" class="table table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col" style="display: none;">idAgrupamientos</th>
                                        <th scope="col">Nombre Tela</th>
                                        <th scope="col">Colores Disponibles</th>
                                        <!-- <th scope="col">Precio</th> -->
                                        <th scope="col">Opciones</th>
                                    </tr>
                                </thead>
                                <!-- id para setear cada elemento en la tabla que creamos desde js -->
                                <tbody id="tblBodyAgrupamientos">

                                </tbody>
                            </table>
                            <!-- Comienzo Ventana Modal Agrupamientos-->
                            <div class="modal fade" id="modalAgrupamientos" tabindex="-1">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Nueva Cortina</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form id="frmNuevoAgrupamiento">
                                                <div class="row mb-3 px-4">
                                                    <label for="txtNombre" class="form-label">Nombre Tela</label>
                                                    <input type="text" class="form-control" id="txtNombre" name="txtNombre" placeholder="Nombre tela" required>
                                                </div>
                                                <div class="row mb-3 px-4">
                                                    <label for="txtDiaFranco" class="form-label">Colores disponibles</label>
                                                    <input type="text" class="form-control" id="txtDiaFranco" name="txtDiaFranco" placeholder="Colores disponibles" required>
                                                </div>
                                                <div class="row mb-3 px-4">
                                                    <button type="submit" class="btn btn-success ">GUARDAR</button>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">CERRAR</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Fin Ventana Modal Agrupamiento-->

                            <!-- Comienzo Ventana Modificar Modal Agrupamientos-->
                            <div class="modal fade" id="modalModificarAgrupamientos" tabindex="-1">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Modificar Cortina</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form id="frmModificarAgrupamiento">
                                                <div class="row mb-3">
                                                    <input type="hidden" class="form-control" id="txtModalIdAgrupamiento" name="txtModalIdAgrupamiento" required>
                                                </div>
                                                <div class="row mb-3 px-4">
                                                    <label for="txtModalNombreAgrupamiento" class="form-label">Nombre Tela</label>
                                                    <input type="text" class="form-control" id="txtModalNombreAgrupamiento" name="txtModalNombreAgrupamiento" required>
                                                </div>
                                                <div class="row mb-3 px-4">
                                                    <label for="txtModalDiaFranco" class="form-label">Colores Disponibles</label>
                                                    <input type="text" class="form-control" id="txtModalDiaFranco" name="txtModalDiaFranco" required>
                                                </div>
                                                <div class="row mb-3 px-4">
                                                    <button type="submit" class="btn btn-success ">GUARDAR</button>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">CERRAR</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Fin Ventana Modificar Modal Agrupamiento-->

                        </div>
                    </div>
                </div>
                <!-- Fin tabla agrupamientos-->

                <!-- Comienzo tabla Area-->
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Productos</h5>
                            <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalAreas">
                                Nuevo Producto
                            </button>
                            <br>
                            <br>
                            <table id="tblAreas" class="table table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col">Producto</th>
                                        <th scope="col">Opciones</th>
                                    </tr>
                                </thead>
                                <tbody id="tblBodyAreas">

                                </tbody>
                            </table>
                            <!-- Comienzo Ventana Modal Areas-->
                            <div class="modal fade" id="modalAreas" tabindex="-1">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Producto</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form id="frmNuevoArea">
                                                <div class="row mb-3 px-4">
                                                    <label for="txtNombreArea" class="form-label">Nombre</label>
                                                    <input type="text" class="form-control" id="txtNombreArea" name="txtNombreArea" placeholder="Nombre" required>
                                                </div>
                                                <div class="row mb-3 px-4">
                                                    <button type="submit" class="btn btn-success ">GUARDAR</button>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">CERRAR</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Fin Ventana Modal Areas-->
                            </section>

</main>


<?php
require "../template/footer.php";
?>

<script src="../template/js/functions-clasificacion.js"></script>