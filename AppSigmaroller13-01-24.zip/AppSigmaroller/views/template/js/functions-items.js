//// FUNCIONES PARA OBTENER VALOR CORTINA ////
// Valor CR //
document.addEventListener("DOMContentLoaded", function() {
    traerItems();
    var select = document.getElementById("selTela");
    var inputAnchoCR = document.getElementById("ancho");
    var inputAltoCR= document.getElementById("alto");
    var selCadCR= document.getElementById("selCadena");
    var selectSop = document.getElementById("selSoporte");
    var selectMR = document.getElementById("selMR");
    var selectMot = document.getElementById("selMotor");
    var checkbox1 = document.getElementById("zocalo");
    var checkbox2 = document.getElementById("termofusion");
    var checkbox3 = document.getElementById("mecCol");
    var checkbox4 = document.getElementById("contrapeso");
    var selectDup = document.getElementById("selDuplica");
    
    var inputPrecio = document.getElementById("valor");
    var valorCadenaCR;
    var valorTotalCR = 0;
    
      

    function actualizarValorTotalCR() {
        // Obtiene el valor seleccionado de cada select y los suma al valor total
        valorTotalCR = 0.00;
        var areaCR;
        
    
        var selectedOption = select.options[select.selectedIndex];
        if (selectedOption.disabled === false){
            precioTelaCR = parseFloat(selectedOption.getAttribute("data-precio"));
            // console.log(precioTelaCR);
            if (inputAnchoCR!== 0) {
                anchoCR = parseFloat(inputAnchoCR.value);
                // console.log(anchoCR);
            }
    
            if (inputAltoCR!== 0) {
                altoCR = parseFloat(inputAltoCR.value);
                // console.log(altoCR);
            }
            areaCR = anchoCR*altoCR;
            valorTotalCR = precioTelaCR*areaCR;
        } 
    
        var selectedOptionCad = selCadCR.options[selCadCR.selectedIndex];
        if (selectedOptionCad.disabled === false){
            valorCadenaCR = parseFloat(selectedOptionCad.getAttribute("data-precioCad"));      
            // console.log(valorCadenaCR);
            valorTotalCR += valorCadenaCR;
        }
        
        var selectedOptinSop = selectSop.options[selectSop.selectedIndex];
        if (selectedOptinSop.disabled === false){
            valorTotalCR += parseFloat(selectedOptinSop.getAttribute("data-precioSop"));      
        }

        var selectedOptionMR = selectMR.options[selectMR.selectedIndex];
        if (selectedOptionMR.disabled === false){
            valorTotalCR += parseFloat(selectedOptionMR.getAttribute("data-precioMR"));      
        }

        var selectedOptionMot = selectMot.options[selectMot.selectedIndex];
        if (selectedOptionMot.disabled === false){
            valorTotalCR += parseFloat(selectedOptionMot.getAttribute("data-precioMCR"));      
        }

        var selectedOptionDup = selectDup.options[selectDup.selectedIndex];
        if (selectedOptionDup.value == "Si") {
            valorTotalCR = valorTotalCR*2;
            // console.log(selectedOptionDup.value);
        } else {
            valorTotalCR = valorTotalCR*1;
        }

        if (checkbox1.checked) {
            valorTotalCR += parseFloat(checkbox1.getAttribute("data-precio"));
        }
        if (checkbox2.checked) {
            valorTotalCR += parseFloat(checkbox2.getAttribute("data-precio"));
        }
        if (checkbox3.checked) {
            valorTotalCR += parseFloat(checkbox3.getAttribute("data-precio"));
        }
        if (checkbox4.checked) {
            valorTotalCR += parseFloat(checkbox4.getAttribute("data-precio"));
        }

       valorTotalCR = valorTotalCR.toFixed(2);
    //    // Separar la parte entera y la parte decimal
    //    let partes = valorTotalCR.split('.');
    //    let parteEntera = partes[0];
    //    let parteDecimal = partes[1];
    //    // Agregar puntos como separadores de miles
    //    parteEntera = parteEntera.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    //    // Unir las partes con una coma como separador decimal
    //    valorTotalCR = parteEntera + ',' + parteDecimal;
    //     console.log(valorTotalCR);
        // Actualiza el input con el nuevo valor total
        inputPrecio.value = valorTotalCR;
    }

    verificarAncho = () => {
        let ancho = parseFloat(inputAnchoCR.value);
    
        if(ancho <= 0.50){
            swal("Garantia!", 'El ANCHO de la cortina inferior a 0.50 mts. no tendra GARANTIA.', "info");
        }
    
    }

    // Agrega controladores de eventos a los tres select
    select.addEventListener("change", actualizarValorTotalCR);
    inputAnchoCR.addEventListener("input", actualizarValorTotalCR);
    inputAnchoCR.addEventListener("change", verificarAncho);
    inputAltoCR.addEventListener("input", actualizarValorTotalCR);
    selCadCR.addEventListener("change", actualizarValorTotalCR);
    selectSop.addEventListener("change", actualizarValorTotalCR);
    selectMR.addEventListener("change", actualizarValorTotalCR);
    selectMot.addEventListener("change", actualizarValorTotalCR);
    checkbox1.addEventListener("change", actualizarValorTotalCR);
    checkbox2.addEventListener("change", actualizarValorTotalCR);
    checkbox3.addEventListener("change", actualizarValorTotalCR);
    checkbox4.addEventListener("change", actualizarValorTotalCR);
    selectDup.addEventListener("change", actualizarValorTotalCR);
    
});

// Valor CBV //
document.addEventListener("DOMContentLoaded", function() {
    var select1 = document.getElementById("selTela1");
    var inputAnchoBV = document.getElementById("numAnchoCBV");
    var inputAltoBV= document.getElementById("numAltoCBV");
    var selMecBV= document.getElementById("selMecCBV");
    var selMotBV= document.getElementById("selMotCBV");
    var selApBV= document.getElementById("selAperCBV");
    var selectDupBV = document.getElementById("selDupCBV");

    var inputPrecioBV = document.getElementById("numValorCBV");
    var areaBV;
    var valorTotalBV = 0;

    function actualizarValorTotalBV() {
        // Obtiene el valor seleccionado de cada select y los suma al valor total
        valorTotalBV = 0.00;
        
        var selectedOptionTela = select1.options[select1.selectedIndex];
        if (selectedOptionTela.disabled === false){
            precioTelaBV = parseFloat(selectedOptionTela.getAttribute("data-precio"));
            // console.log(precioTelaBV);
            if (inputAnchoBV !== 0) {
                anchoBV = parseFloat(inputAnchoBV.value);
                // console.log(anchoBV);
            }
    
            if (inputAltoBV !== 0) {
                altoBV = parseFloat(inputAltoBV.value);
                // console.log(altoBV);
            }
            areaBV = anchoBV*altoBV;
            valorTotalBV = precioTelaBV*areaBV;
        } 

        var selOptionMecBV = selMecBV.options[selMecBV.selectedIndex];
        if (selOptionMecBV.disabled === false){
            valorTotalBV += parseFloat(selOptionMecBV.getAttribute("data-precio"));      
        }

        var selOptionMotBV = selMotBV.options[selMotBV.selectedIndex];
        if (selOptionMotBV.disabled === false){
            valorTotalBV += parseFloat(selOptionMotBV.getAttribute("data-precio"));      
        }

        var selOptionApBV = selApBV.options[selApBV.selectedIndex];
        if (selOptionApBV.disabled === false){
            valorTotalBV += parseFloat(selOptionApBV.getAttribute("data-precio"));      
        }

        var selectedOptionDupBV = selectDupBV.options[selectDupBV.selectedIndex];
        if (selectedOptionDupBV.value == "Si") {
            valorTotalBV = valorTotalBV*2;
            // console.log(selectedOptionDup.value);
        } else {
            valorTotalBV = valorTotalBV*1;
        }


        // Actualiza el input con el nuevo valor total
        inputPrecioBV.value = valorTotalBV.toFixed(2);
    }  

    select1.addEventListener("change", actualizarValorTotalBV);
    inputAnchoBV.addEventListener("input", actualizarValorTotalBV);
    inputAltoBV.addEventListener("input", actualizarValorTotalBV);
    selMecBV.addEventListener("change", actualizarValorTotalBV);
    selMotBV.addEventListener("change", actualizarValorTotalBV);
    selApBV.addEventListener("change", actualizarValorTotalBV);
    selectDupBV.addEventListener("change", actualizarValorTotalBV);

});

// Valor CC //
document.addEventListener("DOMContentLoaded", function() {
    var select2 = document.getElementById("selTela2");
    var inputAnchoCC = document.getElementById("numAnchoCC");
    var inputAltoCC= document.getElementById("numAltoCC");

    var inputPrecioCC = document.getElementById("numValorCC");
    var areaCC;
    var valorTotalCC = 0;

    function actualizarValorTotalCC() {
        // Obtiene el valor seleccionado de cada select y los suma al valor total
        valorTotalCC = 0.00;
        
        var selectedOptionTela = select2.options[select2.selectedIndex];
        if (selectedOptionTela.disabled === false){
            precioTelaCC = parseFloat(selectedOptionTela.getAttribute("data-precio"));
            // console.log(precioTelaCC);
            if (inputAnchoCC !== 0) {
                anchoCC = parseFloat(inputAnchoCC.value);
                // console.log(anchoCC);
            }
    
            if (inputAltoCC !== 0) {
                altoCC = parseFloat(inputAltoCC.value);
                // console.log(altoCC);
            }
            areaCC = anchoCC*altoCC;
            valorTotalCC = precioTelaCC*areaCC;
        } 

        // Actualiza el input con el nuevo valor total
        inputPrecioCC.value = valorTotalCC.toFixed(2);
    }  

    select2.addEventListener("change", actualizarValorTotalCC);
    inputAnchoCC.addEventListener("input", actualizarValorTotalCC);
    inputAltoCC.addEventListener("input", actualizarValorTotalCC);

});



////  FUNCIONES NUEVO PEDIDO  ////

// Agregar CR //
if (document.querySelector("#frmCortinaRoller")) {
    let frmCortinaRoller = document.querySelector("#frmCortinaRoller");
    frmCortinaRoller.onsubmit = function (e) {
        e.preventDefault(); // para que no se recargue la pagina
        fntGuardarCR();
    }

    async function fntGuardarCR() {
        let inputAncho = document.querySelector("#ancho");
        let ancho = parseFloat(inputAncho.value);
        var selAnchoMR= document.getElementById("selMR");
        var anchoMR;
        var selectedOptionAncho = selAnchoMR.options[selAnchoMR.selectedIndex];
        if (selectedOptionAncho.disabled === false){
            anchoMR = parseFloat(selectedOptionAncho.getAttribute("data-ancho"));      
        }

        if (anchoMR >= ancho){
            try {
                const data = new FormData(frmCortinaRoller);
                let resp = await fetch(base_url + "controllers/agregarProducto.php?op=guardarCR", {
                    method: 'POST',
                    mode: 'cors',
                    cache: 'no-cache',
                    body: data
                });
                json = await resp.json();
                if (json.status) {
                    swal("Item", json.msg, "success")
                        .then(() => {
                            frmCortinaRoller.reset();
                            location.reload();
                        });
    
                } else {
                    swal("Item", json.msg, "error");
                }
    
            } catch (err) {
                console.log("Ocurrio un error: " + er);
            }
            
        }else{
            swal("Error de Mecanismo", 'El ancho max. del Mecanismo Roller debe ser superior al ANCHO ingresado', "error");
        }
    }
}

// Agregar CBV //

if (document.querySelector("#frmCortinaBV")) {
    let frmCortinaBV = document.querySelector("#frmCortinaBV");
    frmCortinaBV.onsubmit = function (e) {
        e.preventDefault(); // para que no se recargue la pagina
        fntGuardarCBV();
    }

    async function fntGuardarCBV() {

        try {
            const data = new FormData(frmCortinaBV);
            let resp = await fetch(base_url + "controllers/agregarProducto.php?op=guardarCBV", {
                method: 'POST',
                mode: 'cors',
                cache: 'no-cache',
                body: data
            });
            json = await resp.json();
            if (json.status) {
                swal("Item", json.msg, "success")
                    .then(() => {
                        frmCortinaBV.reset();
                        location.reload();
                    });

            } else {
                swal("Item", json.msg, "error");
            }

        } catch (err) {
            console.log("Ocurrio un error: " + er);
        }
    }
}

// Agregar CC //

if (document.querySelector("#frmCortinaConfec")) {
    let frmCortinaConfec = document.querySelector("#frmCortinaConfec");
    frmCortinaConfec.onsubmit = function (e) {
        e.preventDefault(); // para que no se recargue la pagina
        fntGuardarCC();
    }

    async function fntGuardarCC() {

        try {
            const data = new FormData(frmCortinaConfec);
            let resp = await fetch(base_url + "controllers/agregarProducto.php?op=guardarCC", {
                method: 'POST',
                mode: 'cors',
                cache: 'no-cache',
                body: data
            });
            json = await resp.json();

            if (json.status) {
                swal("Item", json.msg, "success")
                    .then(() => {
                        frmCortinaConfec.reset();
                        location.reload();
                    });



            } else {
                swal("Item", json.msg, "error");
            }

        } catch (err) {
            console.log("Ocurrio un error: " + er);
        }
    }
}

// FUNCIONES GUARDAR ITEM PRODUCTO SELECCIONADO  //
async function fntGuardarItemProd(idProducto) {
    let idPed = document.querySelector("#idPedidoPro");
    idPed = idPed.value;
    var sel1 = "#precio-unitario_" + idProducto;
    let valorUni = document.querySelector(sel1);
    valorUni = valorUni.textContent;
    valorUni = valorUni.replace(/\D/g, '');
    var sel2 = "#cantSel_" + idProducto;
    let cantidad = document.querySelector(sel2);
    cantidad = cantidad.value;

    try {
        const data = new FormData();
        data.append('idPro', idProducto);
        data.append('idPed', idPed);
        data.append('valorUni', valorUni);
        data.append('cantidad', cantidad);

        let resp = await fetch(base_url + "controllers/agregarProducto.php?op=guardarItemProd", {
            method: 'POST',
            mode: 'cors',
            cache: 'no-cache',
            body: data
        });
        json = await resp.json();

        if (json.status) {
            swal("Agregar Producto", json.msg, "success")
                .then(() => {
                    location.reload();
                });



        } else {
            swal("Agregar cortina", json.msg, "error");
        }

    } catch (err) {
        console.log("Ocurrio un error: " + er);
    }
}

// function fntACR(id) {
//     var sel2 = "cantSelCR_" + id;
//     let cantidad = document.getElementById(sel2);
//     cantidad = cantidad.value;
//     console.log(cantidad);
     
// }


////CREAR TABLA DE ITEMS POR NRO DE PEDIDO///
async function traerItems() {

    try {
        let obId = document.querySelector("#obtenerId");
        let idPedido = obId.value;
        const data = new FormData();
        data.append('id', idPedido);
        let resp = await fetch(base_url + "controllers/items.php?op=listItems", {
            method: 'POST',
            mode: 'cors',
            cache: 'no-cache',
            body: data
        });
        json = await resp.json();
        if (json.status) {
            let data = json.data;
            data.forEach(item => {
                let valor = item.valorTotal;
                // Separar la parte entera y la parte decimal
                let partes = valor.split('.');
                let parteEntera = partes[0];
                let parteDecimal = partes[1];
                // Agregar puntos como separadores de miles
                parteEntera = parteEntera.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
                // Unir las partes con una coma como separador decimal
                valor = parteEntera + ',' + parteDecimal;
                
                let valorU = item.valorUnitario;
                // Separar la parte entera y la parte decimal
                let partesU = valorU.split('.');
                let parteEnteraU = partesU[0];
                let parteDecimalU = partesU[1];
                // Agregar puntos como separadores de miles
                parteEnteraU = parteEnteraU.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
                // Unir las partes con una coma como separador decimal
                valorU = parteEnteraU + ',' + parteDecimalU;
               
                
                let newtr = document.createElement("tr");
                newtr.id = "row_ " + item.idItem;
                newtr.innerHTML = `<tr>
                                                <th scope="row" style="display: none;">${item.idItem}</th>
                                                <td style="text-align: center">${item.itemSelec}</td>
                                                <td style="text-align: center">${item.cantidad}</td>
                                                <td style="text-align: center">$ ${valorU}</td>
                                                <td style="text-align: center">$ ${valor}</td>
                                                <td style="text-align: center">${item.options}</td>`;
                document.querySelector("#tblBodyItems").appendChild(newtr);
            });
        }
        let valorTotal = json.valorTotal.toFixed(2);
        // Separar la parte entera y la parte decimal
        let partes = valorTotal.split('.');
        let parteEntera = partes[0];
        let parteDecimal = partes[1];
        // Agregar puntos como separadores de miles
        parteEntera = parteEntera.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
        // Unir las partes con una coma como separador decimal
        valorTotal = parteEntera + ',' + parteDecimal;

        let inputvalorTotal = document.querySelector("#valorTotal");
        inputvalorTotal.value = valorTotal ;

    } catch (err) {
        console.log("Ocurrio un error" + err);
    }
}

async function traerValorTotal(){
    try {
        
    } catch (error) {
        console.log("Ocurrio un error" + error);
    }
}


///////////  FUNCIONES DE MODIFICAR y VER ////////////////
// Funcion modificar Cortina Roller
async function fntModCR(id, idItem){
    let formData = new FormData();
    formData.append('idCR', id);
    try {
        let resp = await fetch(base_url + "controllers/items.php?op=modItemCR", {
            method: 'POST',
            mode: 'cors',
            cache: 'no-cache',
            body: formData
        });
        json = await resp.json();
        if (json.status) {
            //aca copiar datos en modal
            let idCR = document.querySelector("#idCR");
            idCR.value = id;
            let idCRItem = document.querySelector("#idCRItem");
            idCRItem.value = idItem;
            let nombre = document.querySelector("#nombre");
            nombre.value = json.data.nombre;
            let selTela = document.querySelector("#selTela");
            selTela.value = json.data.tela;
            obtenerTela();
            let selColor = document.querySelector("#selColor");
            selColor.value = json.data.color;
            let ancho = document.querySelector("#ancho");
            ancho.value = json.data.ancho;
            let alto = document.querySelector("#alto");
            alto.value = json.data.alto;
            let selCadena = document.querySelector("#selCadena");
            selCadena.value = json.data.cadena;
           
            let selComando = document.querySelector("#selComando");
            selComando.value = json.data.comando;
            let selCaida = document.querySelector("#selCaida");
            selCaida.value = json.data.caida;
            let selMR = document.querySelector("#selMR");
            selMR.value = json.data.idMecanismoRoller;
            let selSoporte = document.querySelector("#selSoporte");
            selSoporte.value = json.data.idSoporte;
            let selMotor = document.querySelector("#selMotor");
            selMotor.value = json.data.idMotorCR;
            let selDuplica = document.querySelector("#selDuplica");
            selDuplica.value = json.data.duplica;
            let cantidad = document.querySelector("#cantidad");
            cantidad.value = json.data.cantidad;
            let observaciones = document.querySelector("#observaciones");
            observaciones.value = json.data.observaciones;
            let valor = document.querySelector("#valor");
            valor.value = json.data.valor;
            if(json.data.zocalo == "1"){
                let zocalo = document.querySelector("#zocalo");
                zocalo.checked = true;
            }
            if(json.data.termofusion == "1"){
                let termofusion = document.querySelector("#termofusion");
                termofusion.checked = true;
            }
            if(json.data.mecanismoColor == "1"){
                let mecanismoColor = document.querySelector("#mecCol");
                mecanismoColor.checked = true;
            }
            if(json.data.contrapesoCadena == "1"){
                let contrapeso = document.querySelector("#contrapeso");
                contrapeso.checked = true;
            }

            let modal = new bootstrap.Modal(document.getElementById('cortinaRoller'));
            modal.show(); 
        } else {
            location.reload();
        }
    } catch (err) {
        console.log("Ocurrio un error: " + err);
    }

}
// Funcion Ver Cortina Roller
async function fntVerCR(id, idItem){
    let formData = new FormData();
    formData.append('idCR', id);
    try {
        let resp = await fetch(base_url + "controllers/items.php?op=modItemCR", {
            method: 'POST',
            mode: 'cors',
            cache: 'no-cache',
            body: formData
        });
        json = await resp.json();
        if (json.status) {
            //aca copiar datos en modal
            let idCR = document.querySelector("#idCR");
            idCR.value = id;
            let idCRItem = document.querySelector("#idCRItem");
            idCRItem.value = idItem;
            let nombre = document.querySelector("#nombre");
            nombre.value = json.data.nombre;
            let selTela = document.querySelector("#selTela");
            selTela.value = json.data.tela;
            obtenerTela();
            let selColor = document.querySelector("#selColor");
            selColor.value = json.data.color;
            let ancho = document.querySelector("#ancho");
            ancho.value = json.data.ancho;
            let alto = document.querySelector("#alto");
            alto.value = json.data.alto;
            let selCadena = document.querySelector("#selCadena");
            selCadena.value = json.data.cadena;
           
            let selComando = document.querySelector("#selComando");
            selComando.value = json.data.comando;
            let selCaida = document.querySelector("#selCaida");
            selCaida.value = json.data.caida;
            let selMR = document.querySelector("#selMR");
            selMR.value = json.data.idMecanismoRoller;
            let selSoporte = document.querySelector("#selSoporte");
            selSoporte.value = json.data.idSoporte;
            let selMotor = document.querySelector("#selMotor");
            selMotor.value = json.data.idMotorCR;
            let selDuplica = document.querySelector("#selDuplica");
            selDuplica.value = json.data.duplica;
            let cantidad = document.querySelector("#cantidad");
            cantidad.value = json.data.cantidad;
            let observaciones = document.querySelector("#observaciones");
            observaciones.value = json.data.observaciones;
            let valor = document.querySelector("#valor");
            valor.value = json.data.valor;
            if(json.data.zocalo == "1"){
                let zocalo = document.querySelector("#zocalo");
                zocalo.checked = true;
            }
            if(json.data.termofusion == "1"){
                let termofusion = document.querySelector("#termofusion");
                termofusion.checked = true;
            }
            if(json.data.mecanismoColor == "1"){
                let mecanismoColor = document.querySelector("#mecCol");
                mecanismoColor.checked = true;
            }
            if(json.data.contrapesoCadena == "1"){
                let contrapeso = document.querySelector("#contrapeso");
                contrapeso.checked = true;
            }
            //Para deshabilitar todas las etiquetas y btn de terminar
            let btn = document.querySelector("#btnFinCR");
            btn.style.display = "none";
            // Deshabilitar todos los elementos de formulario
            let formElements = document.querySelectorAll("#cortinaRoller input, #cortinaRoller select, #cortinaRoller textarea");
            formElements.forEach(element => {
                element.disabled = true;
            });

            let modal = new bootstrap.Modal(document.getElementById('cortinaRoller'));
            modal.show(); 
        } else {
            location.reload();
        }
    } catch (err) {
        console.log("Ocurrio un error: " + err);
    }

}

// Funcion modificar Cortina Banda Vertical
async function fntModCBV(id, idItem){
    let formData = new FormData();
    formData.append('idCBV', id);
    try {
        let resp = await fetch(base_url + "controllers/items.php?op=modItemCBV", {
            method: 'POST',
            mode: 'cors',
            cache: 'no-cache',
            body: formData
        });
        json = await resp.json();
        if (json.status) {
            //aca copiar datos en modal
            let idCBV = document.querySelector("#idCBV");
            idCBV.value = id;
            let idCBVItem = document.querySelector("#idCBVItem");
            idCBVItem.value = idItem;
            let nombre = document.querySelector("#nombreCBV");
            nombre.value = json.data.nombre;
            let selTela = document.querySelector("#selTela1");
            selTela.value = json.data.tela;
            obtenerTela1();
            let selColor = document.querySelector("#selColor1");
            selColor.value = json.data.color;
            let ancho = document.querySelector("#numAnchoCBV");
            ancho.value = json.data.ancho;
            let alto = document.querySelector("#numAltoCBV");
            alto.value = json.data.alto;
            let selComando = document.querySelector("#selComandoCBV");
            selComando.value = json.data.comando;
            let selMecCBV = document.querySelector("#selMecCBV");
            selMecCBV.value = json.data.idMecanismoBandaVertical;
            let selMen = document.querySelector("#selMenCBV");
            selMen.value = json.data.mensulas;
            let selMotorCBV = document.querySelector("#selMotCBV");
            selMotorCBV.value = json.data.idMotorBandaVertical;
            let selAperCBV = document.querySelector("#selAperCBV");
            selAperCBV.value = json.data.idApertura;
            let selValorCBV = document.querySelector("#numValorCBV");
            selValorCBV.value = json.data.valor;
            let cantidadCBV = document.querySelector("#numCantCBV");
            cantidadCBV.value = json.data.cantidad;
            let duplicaCBV = document.querySelector("#selDupCBV");
            duplicaCBV.value = json.data.duplica;
            let txtObsCBV = document.querySelector("#txtObsCBV");
            txtObsCBV.value = json.data.observacion;

            let modal = new bootstrap.Modal(document.getElementById('CortinaBV'));
            modal.show();
        } else {
            location.reload();
        }
    } catch (err) {
        console.log("Ocurrio un error: " + err);
    }

}
// Funcion ver Cortina Banda Vertical
async function fntVerCBV(id, idItem){
    let formData = new FormData();
    formData.append('idCBV', id);
    try {
        let resp = await fetch(base_url + "controllers/items.php?op=modItemCBV", {
            method: 'POST',
            mode: 'cors',
            cache: 'no-cache',
            body: formData
        });
        json = await resp.json();
        if (json.status) {
            //aca copiar datos en modal
            let idCBV = document.querySelector("#idCBV");
            idCBV.value = id;
            let idCBVItem = document.querySelector("#idCBVItem");
            idCBVItem.value = idItem;
            let nombre = document.querySelector("#nombreCBV");
            nombre.value = json.data.nombre;
            let selTela = document.querySelector("#selTela1");
            selTela.value = json.data.tela;
            obtenerTela1();
            let selColor = document.querySelector("#selColor1");
            selColor.value = json.data.color;
            let ancho = document.querySelector("#numAnchoCBV");
            ancho.value = json.data.ancho;
            let alto = document.querySelector("#numAltoCBV");
            alto.value = json.data.alto;
            let selComando = document.querySelector("#selComandoCBV");
            selComando.value = json.data.comando;
            let selMecCBV = document.querySelector("#selMecCBV");
            selMecCBV.value = json.data.idMecanismoBandaVertical;
            let selMen = document.querySelector("#selMenCBV");
            selMen.value = json.data.mensulas;
            let selMotorCBV = document.querySelector("#selMotCBV");
            selMotorCBV.value = json.data.idMotorBandaVertical;
            let selAperCBV = document.querySelector("#selAperCBV");
            selAperCBV.value = json.data.idApertura;
            let selValorCBV = document.querySelector("#numValorCBV");
            selValorCBV.value = json.data.valor;
            let cantidadCBV = document.querySelector("#numCantCBV");
            cantidadCBV.value = json.data.cantidad;
            let duplicaCBV = document.querySelector("#selDupCBV");
            duplicaCBV.value = json.data.duplica;
            let txtObsCBV = document.querySelector("#txtObsCBV");
            txtObsCBV.value = json.data.observacion;

             //Para deshabilitar todas las etiquetas y btn de terminar
             let btnBV = document.querySelector("#btnFinCBV");
             btnBV.style.display = "none";
             // Deshabilitar todos los elementos de formulario
             let formElements = document.querySelectorAll("#CortinaBV input, #CortinaBV select, #CortinaBV textarea");
             formElements.forEach(element => {
                 element.disabled = true;
             });

            let modal = new bootstrap.Modal(document.getElementById('CortinaBV'));
            modal.show();
        } else {
            location.reload();
        }
    } catch (err) {
        console.log("Ocurrio un error: " + err);
    }

}

// Funcion modificar Cortina Confeccion
async function fntModCC(id, idItem){
    let formData = new FormData();
    formData.append('idCC', id);
    try {
        let resp = await fetch(base_url + "controllers/items.php?op=modItemCC", {
            method: 'POST',
            mode: 'cors',
            cache: 'no-cache',
            body: formData
        });
        json = await resp.json();
        if (json.status) {
            //aca copiar datos en modal
            let idCC = document.querySelector("#idCC");
            idCC.value = id;
            let idCCItem = document.querySelector("#idCCItem");
            idCCItem.value = idItem;
            let nombre = document.querySelector("#nombreCC");
            nombre.value = json.data.nombre;
            let selTela = document.querySelector("#selTela2");
            selTela.value = json.data.tela;
            obtenerTela2();
            let selColor = document.querySelector("#selColor2");
            selColor.value = json.data.color;
            let ancho = document.querySelector("#numAnchoCC");
            ancho.value = json.data.ancho;
            let alto = document.querySelector("#numAltoCC");
            alto.value = json.data.alto;
            let numValorCC = document.querySelector("#numValorCC");
            numValorCC.value = json.data.valor;
            let txtObsCC = document.querySelector("#txtObsCC");
            txtObsCC.value = json.data.observacion;

            let modal = new bootstrap.Modal(document.getElementById('CortinaConfeccion'));
            modal.show();
        } else {
            location.reload();
        }
    } catch (err) {
        console.log("Ocurrio un error: " + err);
    }

}
// Funcion Ver Cortina Confeccion
async function fntVerCC(id, idItem){
    let formData = new FormData();
    formData.append('idCC', id);
    try {
        let resp = await fetch(base_url + "controllers/items.php?op=modItemCC", {
            method: 'POST',
            mode: 'cors',
            cache: 'no-cache',
            body: formData
        });
        json = await resp.json();
        if (json.status) {
            //aca copiar datos en modal
            let idCC = document.querySelector("#idCC");
            idCC.value = id;
            let idCCItem = document.querySelector("#idCCItem");
            idCCItem.value = idItem;
            let nombre = document.querySelector("#nombreCC");
            nombre.value = json.data.nombre;
            let selTela = document.querySelector("#selTela2");
            selTela.value = json.data.tela;
            obtenerTela2();
            let selColor = document.querySelector("#selColor2");
            selColor.value = json.data.color;
            let ancho = document.querySelector("#numAnchoCC");
            ancho.value = json.data.ancho;
            let alto = document.querySelector("#numAltoCC");
            alto.value = json.data.alto;
            let numValorCC = document.querySelector("#numValorCC");
            numValorCC.value = json.data.valor;
            let txtObsCC = document.querySelector("#txtObsCC");
            txtObsCC.value = json.data.observacion;

            //Para deshabilitar todas las etiquetas y btn de terminar
            let btnCC = document.querySelector("#btnFinCC");
            btnCC.style.display = "none";
            // Deshabilitar todos los elementos de formulario
            let formElements = document.querySelectorAll("#CortinaConfeccion input, #CortinaConfeccion select, #CortinaConfeccion textarea");
            formElements.forEach(element => {
                element.disabled = true;
            });

            let modal = new bootstrap.Modal(document.getElementById('CortinaConfeccion'));
            modal.show();
        } else {
            location.reload();
        }
    } catch (err) {
        console.log("Ocurrio un error: " + err);
    }

}

///////// FUNCION PARA ELIMINAR ITEMS
function fntEliminarItem(id) {

    swal({
        title: "Queres eliminar el Item?",
        text: "Se eliminara el item del Pedido",
        icon: "warning",
        buttons: true,
        dangerMode: true,
    })
        .then((willDelete) => {
            if (willDelete) {
                fntDeleteItem(id);
            }
        });

}

async function fntDeleteItem(id) {
    try {
        let formData = new FormData();
        formData.append('id', id);
        let resp = await fetch(base_url + "controllers/items.php?op=eliminar", {
            method: 'POST',
            mode: 'cors',
            cache: 'no-cache',
            body: formData
        });
        json = await resp.json();
        if (json.status) {
            swal("Eliminar", json.msg, "success")
                .then(() => {
                    location.reload();
                });
        } else {
            swal("Eliminar", json.msg, "error");
        }
    } catch (err) {
        console.log("Ocurrio un error: " + err);
    }
}