<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sigma Roller - Detalles del Pedido</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
        body {
            font-family: 'Times New Roman';
            font-size: 12pt;
        }

        .order-details {
            margin: 20px;
        }

        .order-info {
            margin-top: 8px;
            margin-bottom: 12px;
        }

        .product-details {
            margin-top: 10px;
            text-align: justify;
            line-height: 1.4;
        }

        .qr-code-container {
            text-align: center;
            margin-top: 20px;
            position: relative;
        }

        #qrCode {
            margin-bottom: 10px; /* Espacio entre el código QR y el botón */
        }

        /* Clase para ocultar el botón por defecto */
        .hidden {
            display: none;
        }
    </style>
</head>

<body>
    <div class="container order-details">
        <h2 class="text-center">Detalles del Pedido</h2>

        <div class="order-info">
            <p><span class="font-weight-bold">Pedido:</span> 12371</p>
            <p><span class="font-weight-bold">Fecha:</span> 2023-09-30</p>
            <p><span class="font-weight-bold">Cliente:</span> Rosana Testardin</p>
        </div>

        <div class="product-details">
            <p><span class="font-weight-bold">Producto:</span> 2x Poliéster liso gris perla-1622</p>
            <p><span class="font-weight-bold">Medidas:</span> 2.35 x 2.80 Izq-CN</p>
            <p><span class="font-weight-bold">Material:</span> Plástico</p>
            <p><span class="font-weight-bold">Mecanismo:</span> Motor eléctrico</p>
            <p><span class="font-weight-bold">Control:</span> Remoto de 5 canales</p>
        </div>

        <div class="row justify-content-center">
            <div class="col-md-6 qr-code-container">
                <!-- Integra un código QR básico con la biblioteca QRCode.js -->
                <div id="qrCode"></div>
                <!-- Botón para cambiar el estado del pedido -->
                <button id="changeOrderBtn" class="btn btn-primary btn-block mt-3 hidden"
                    onclick="changeOrderStatus()">Cambiar Estado del Pedido</button>
            </div>
        </div>
    </div>

    <!-- Incluye la biblioteca QRCode.js -->
    <script src="https://cdn.rawgit.com/davidshimjs/qrcodejs/gh-pages/qrcode.min.js"></script>

    <script>
        // Función para generar el código QR
        function generateQRCode() {
            var qr = new QRCode(document.getElementById("qrCode"), {
                text: "URL o datos para el escaneo",
                width: 128,
                height: 128
            });

            // Muestra el botón después de generar el código QR
            document.getElementById("changeOrderBtn").classList.remove("hidden");
        }

        // Función para cambiar el estado del pedido
        function changeOrderStatus() {
            // Implementa la lógica para cambiar el estado del pedido en la base de datos (MySQL) aquí
            alert("¿Desea cambiar el estado del pedido?");
        }

        // Llama a la función para generar el código QR al cargar la página
        generateQRCode();
    </script>
</body>

</html>