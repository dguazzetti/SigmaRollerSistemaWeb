<?php

if(!isset($_SESSION)){
  session_start();
}
//Obtengo los datos de la sesion
$nombre = $_SESSION['usuario'];
$nombre = ucfirst($nombre);
$tipoUsuario = $_SESSION['tipoUsuario'];
$tipoUsuario = ucfirst($tipoUsuario);

require "../template/head.php";
?>

<body>
  <?php
  require "../template/header.php";

  ?>
  <!-- Main -->
  <main id="main" class="main">

    <div class="pagetitle">
      <h1> Ver Pedido</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?= $baseUrl; ?>/views/pedidos/ver-pedidos.php">Pedido</a></li>
          <li class="breadcrumb-item active">Ver Pedido</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      



    </section>

  </main><!-- End #main -->
