<?php
require_once "../models/productoModel.php";

$option = $_REQUEST['op'];
$objItem = new ProductoModel();
$objCR = new ProductoModel();
$objCBV = new ProductoModel();
$objCC = new ProductoModel();


///// MOSTRAR POR TABLA ITEMS POR PEDIDO ///////
if ($option == "listItems") {
    // var_dump($_POST);
    // exit;
    if($_POST){
        $idPedido = intval($_POST['id']);
    }

    $arrRespuesta = array('status' => false, 'data' => "");
    $arrItems = $objItem->traerItems($idPedido);
    // echo "<pre>"; 
    // var_dump($arrItems);
    // echo "</pre>";
    // exit;
    if (!empty($arrItems)) {
        $valorTotal = 0;
        for ($i = 0; $i < count($arrItems); $i++) {
            $valorItem = $arrItems[$i]->valorTotal;
            $valorItem = floatval($valorItem);

            $valorTotal += $valorItem;
            
            $idItem = $arrItems[$i]->idItem;
            $idProd = $arrItems[$i]->idProducto;
            $idCR = $arrItems[$i]->idCortinaRoller;
            $idBV = $arrItems[$i]->idCortinaBandaVertical;
            $idCC = $arrItems[$i]->idCortinaConfeccion;
            $itemSelec = "";
            
             if (!empty($idProd)) {
                $nombre = $objItem->verNombre($idProd);
                $itemSelec = $nombre->nombre;
                $options = '<button type="button" class="btn  btn-outline-danger btn-sm ms-2" onclick="fntEliminarItem(' . $idItem . ')"><i class="bi bi-trash"></i></button>';
            } elseif (!empty($idCR )) {
                $nombre = $objItem->verNombreCR($idCR);
                $itemSelec = 'CR: '. $nombre->nombre;
                $options = '<button type="button" class="btn  btn-outline-primary btn-sm" onclick="fntModCR(' . $idCR . ', ' . $idItem . ')"><i class="bi bi-pencil-square"></i></button>
                           <button type="button" class="btn  btn-outline-warning btn-sm ms-2" onclick="fntVerCR(' . $idCR . ', ' . $idItem . ')"><i class="bi bi-eye"></i></button>
                           <button type="button" class="btn  btn-outline-danger btn-sm ms-2" onclick="fntEliminarItem(' . $idItem . ')"><i class="bi bi-trash"></i></button>';
            } elseif (!empty($idBV)) {
                $nombre = $objItem->verNombreBV($idBV);
                $itemSelec = 'CBV: '. $nombre->nombre;
                $options = '<button type="button" class="btn  btn-outline-primary btn-sm" onclick="fntModCBV(' . $idBV . ', ' . $idItem . ')"><i class="bi bi-pencil-square"></i></button>
                           <button type="button" class="btn  btn-outline-warning btn-sm ms-2" onclick="fntVerCBV(' . $idBV . ', ' . $idItem . ')"><i class="bi bi-eye"></i></button>
                           <button type="button" class="btn  btn-outline-danger btn-sm ms-2" onclick="fntEliminarItem(' . $idItem . ')"><i class="bi bi-trash"></i></button>';
            } elseif (!empty($idCC)) {
                $nombre = $objItem->verNombreCC($idCC);
                $itemSelec = 'CC: '. $nombre->nombre;
                $options = '<button type="button" class="btn  btn-outline-primary btn-sm" onclick="fntModCC(' . $idCC . ', ' . $idItem . ')"><i class="bi bi-pencil-square"></i></button>
                <button type="button" class="btn  btn-outline-warning btn-sm ms-2" onclick="fntVerCC(' . $idCC . ', ' . $idItem . ')"><i class="bi bi-eye"></i></button>
                           <button type="button" class="btn  btn-outline-danger btn-sm ms-2" onclick="fntEliminarItem(' . $idItem . ')"><i class="bi bi-trash"></i></button>';
            }

            $arrItems[$i]->options = $options;
            $arrItems[$i]->itemSelec = $itemSelec;
        }

        $arrRespuesta['status'] = true;
        $arrRespuesta['data'] = $arrItems;
        $arrRespuesta['valorTotal'] = $valorTotal;
    }
    echo json_encode($arrRespuesta);
    die();
}

if($option == "modItemCR"){
    
    if ($_POST) {
        $id = intval($_POST['idCR']);
        $arrCR = $objCR->getCR($id);
        // echo "<pre>";
        // var_dump($arrCR);
        // echo "</pre>";
        // exit;
        if (empty($arrCR)) {
            $arrRespuesta = array('status' => false, 'msg' => 'Datos no encontrados');
        } else {
            $arrRespuesta = array('status' => true, 'msg' => 'Datos encontrados', 'data' => $arrCR);
        }
        echo json_encode($arrRespuesta);
    }

    die();
}

if($option == "modItemCBV"){
    //  echo "<pre>";
    //     var_dump($_POST);
    //     echo "</pre>";
    //     exit;
    if ($_POST) {
        $id = intval($_POST['idCBV']);
        $arrCBV = $objCBV->getCBV($id);
        if (empty($arrCBV)) {
            $arrRespuesta = array('status' => false, 'msg' => 'Datos no encontrados');
        } else {
            $arrRespuesta = array('status' => true, 'msg' => 'Datos encontrados', 'data' => $arrCBV);
        }
        echo json_encode($arrRespuesta);
    }

    die();
}

if($option == "modItemCC"){
    //  echo "<pre>";
    //     var_dump($_POST);
    //     echo "</pre>";
    //     exit;
    if ($_POST) {
        $id = intval($_POST['idCC']);
        $arrCC = $objCC->getCC($id);
        if (empty($arrCC)) {
            $arrRespuesta = array('status' => false, 'msg' => 'Datos no encontrados');
        } else {
            $arrRespuesta = array('status' => true, 'msg' => 'Datos encontrados', 'data' => $arrCC);
        }
        echo json_encode($arrRespuesta);
    }

    die();
}

if ($option == "eliminar") {
    // echo "<pre>";
    // var_dump($_POST);
    // echo "</pre>";
    // exit;
    if ($_POST) {
        if (empty($_POST['id'])) {
            $arrRespuesta = array('status' => false, 'msg' => 'Error de datos');
        } else {
            $id = intval($_POST['id']);
            $arrInfo = $objItem->delItem($id);
            if ($arrInfo > 0) {
                $arrRespuesta = array('status' => true, 'msg' => 'Item eliminado');
            } else {
                $arrRespuesta = array('status' => false, 'msg' => 'Error al eliminar');
            }
        }
        echo json_encode($arrRespuesta);
    }

}

?>