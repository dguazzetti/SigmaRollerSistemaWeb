<!-- ======= Footer ======= -->
<footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright. All Rights Reserved
    </div>
    <div class="credits">
      Diseñado por SGF Devs.
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<!-- Vendor JS Files -->
  <script src="<?php echo $baseUrl; ?>/assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="<?php echo $baseUrl; ?>/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo $baseUrl; ?>/assets/vendor/chart.js/chart.umd.js"></script>
  <script src="<?php echo $baseUrl; ?>/assets/vendor/echarts/echarts.min.js"></script>
  <script src="<?php echo $baseUrl; ?>/assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="<?php echo $baseUrl; ?>/assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="<?php echo $baseUrl; ?>/assets/vendor/php-email-form/validate.js"></script>

<!-- Main JS File -->
<script>
  const base_url = "<?php echo $baseUrl; ?>/";
</script>
<script src="<?php echo $baseUrl; ?>/assets/js/main.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script src="<?php echo $baseUrl; ?>/assets/js/functions.js">  </script>
</body>

</html>

