<?php
    /// FUNCION SUPERGLOBAL PARA OBTENER BASE URL ///
    function getBaseUrl() {
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'];
        $baseUrl = $protocol . '://' . $host;

        return $baseUrl;
    }

    define('BASE_URL', getBaseUrl());

    $baseUrl = BASE_URL;
    //BaseUrl para Servidor
    // $baseUrl .= '/AppSigmaroller';

    /// CONSTANTES PARA BASE DE DATOS LOCAL///
    const DB_HOST = "localhost";
    const DB_NAME = "appSigmaroller";
    const DB_USER = "root";
    const DB_PASSWORD = "";
    const DB_CHARSET = "utf8";


    /// CONSTANTES PARA BASE DE DATOS SEVIDOR///
    // const DB_HOST = "localhost";
    // const DB_NAME = "c2541829_sigma";
    // const DB_USER = "c2541829_sigma";
    // const DB_PASSWORD = "se50KEropo";
    // const DB_CHARSET = "utf8";


?>
